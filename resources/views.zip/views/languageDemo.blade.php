{{-- @extends('layouts.backend.main') --}}

{{-- @section('content') --}}
<div class="container">
    <div class="row justify-content-center">
        <h3>{{__('messages.welcome')}} {{ $local }}</h3>
    </div>
</div>
{{-- @endsection --}}
