<div class=" pull-right bg-trnsparent" >
    {{-- <img class="avatar user-thumb" src="{{ asset('backend/assets/images/author/avatar.png') }}" alt="avatar"> --}}
    {{-- <a class=" dropdown-toggle" data-toggle="dropdown" style="cursor: pointer;">
    <img src="{{ asset('backend/assets/images/author/icons8-user-64.png') }}" class="rounded-circle" alt="">
    </a>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="{{ route('profile') }}">Profile</a>
        <a class="dropdown-item" href="{{ route('logout') }}">Log Out</a>
    </div> --}}
</div>
