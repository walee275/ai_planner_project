<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <a href="https:://neotronicdev.com">Neotronicdev</a> 2023 <div id="ipAddress"></div></span>
        </div>
    </div>
</footer>
